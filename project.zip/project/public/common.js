// ----- Хранилище и ключи -----
const STORAGE_KEYS = {
  USERS: "edu_users",
  APPLICATIONS: "edu_applications",
  REVIEWS: "edu_reviews",
  CURRENT_USER: "edu_current_user",
};

// Инициализация хранилища (если пусто)
function initStorage() {
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify([]));
  }
  if (!localStorage.getItem(STORAGE_KEYS.APPLICATIONS)) {
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
  }
  if (!localStorage.getItem(STORAGE_KEYS.REVIEWS)) {
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify([]));
  }
}

// Получение данных
function getUsers() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS));
}
function getApplications() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.APPLICATIONS));
}
function getReviews() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.REVIEWS));
}
function getCurrentUser() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.CURRENT_USER));
}

function saveUsers(users) {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}
function saveApplications(apps) {
  localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
}
function saveReviews(reviews) {
  localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
}
function setCurrentUser(user) {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
}
function clearCurrentUser() {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
}

// Валидация полей регистрации
function validateLogin(login) {
  return /^[a-zA-Z0-9]{6,}$/.test(login);
}
function validatePassword(pass) {
  return pass.length >= 8;
}
function validateFullName(name) {
  return /^[А-Яа-яёЁ\s]+$/.test(name.trim());
}
// Новая гибкая проверка телефона (без скобок, тире, с пробелами)
function validatePhone(phone) {
  const cleaned = phone.replace(/[\s\-\(\)]/g, "");
  const regex = /^(\+7|8)?\d{10}$/;
  if (!regex.test(cleaned)) return false;
  if (cleaned.startsWith("8") || cleaned.startsWith("7")) {
    return cleaned.length === 11;
  }
  return cleaned.length === 10;
}
function validateEmail(email) {
  return /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/.test(email);
}

// Регистрация пользователя
function registerUser(login, password, fullName, phone, email) {
  const users = getUsers();
  if (users.find((u) => u.login === login))
    return { success: false, error: "Логин уже существует" };
  if (login === "Admin")
    return { success: false, error: "Логин Admin зарезервирован" };
  if (!validateLogin(login))
    return {
      success: false,
      error: "Логин: только латиница+цифры, минимум 6 символов",
    };
  if (!validatePassword(password))
    return { success: false, error: "Пароль: минимум 8 символов" };
  if (!validateFullName(fullName))
    return { success: false, error: "ФИО: только кириллица и пробелы" };
  if (!validatePhone(phone))
    return {
      success: false,
      error:
        "Некорректный номер телефона. Пример: 89123456789 или +79123456789",
    };
  if (!validateEmail(email))
    return { success: false, error: "Некорректный email" };

  const newUser = { login, password, fullName, phone, email };
  users.push(newUser);
  saveUsers(users);
  return { success: true };
}

// Авторизация (обычный пользователь или админ)
function authenticateUser(login, password) {
  if (login === "Admin" && password === "KorokNET") {
    return {
      success: true,
      role: "admin",
      user: { login: "Admin", fullName: "Administrator" },
    };
  }
  const users = getUsers();
  const found = users.find((u) => u.login === login && u.password === password);
  if (found) {
    return { success: true, role: "user", user: found };
  }
  return { success: false, error: "Неверный логин или пароль" };
}

// Создание заявки
function createApplication(userLogin, courseName, startDate, paymentMethod) {
  const apps = getApplications();
  const newApp = {
    id: Date.now(),
    userLogin: userLogin,
    courseName: courseName.trim(),
    startDate: startDate,
    paymentMethod: paymentMethod,
    status: "Новая",
    createdAt: new Date().toISOString(),
  };
  apps.push(newApp);
  saveApplications(apps);
  return newApp;
}

// Обновление статуса заявки (админ)
function updateApplicationStatus(appId, newStatus) {
  const apps = getApplications();
  const index = apps.findIndex((a) => a.id == appId);
  if (index !== -1) {
    apps[index].status = newStatus;
    saveApplications(apps);
    return true;
  }
  return false;
}

// Получить заявки пользователя
function getUserApplications(login) {
  const apps = getApplications();
  return apps.filter((a) => a.userLogin === login).sort((a, b) => b.id - a.id);
}

// Получить все заявки (для админа)
function getAllApplications() {
  return getApplications().sort((a, b) => b.id - a.id);
}

// ----- Отзывы с привязкой к заявке (курсу) -----
function addReviewForApplication(userLogin, applicationId, text) {
  if (!text.trim()) return false;
  const reviews = getReviews();
  const newReview = {
    id: Date.now(),
    userLogin: userLogin,
    applicationId: applicationId,
    text: text.trim(),
    createdAt: new Date().toISOString(),
  };
  reviews.push(newReview);
  saveReviews(reviews);
  return true;
}

function getReviewsForApplication(applicationId) {
  const reviews = getReviews();
  return reviews
    .filter((r) => r.applicationId === applicationId)
    .sort((a, b) => b.id - a.id);
}

// Общие отзывы (без привязки к заявке)
function addGeneralReview(userLogin, text) {
  if (!text.trim()) return false;
  const reviews = getReviews();
  const newReview = {
    id: Date.now(),
    userLogin: userLogin,
    applicationId: null,
    text: text.trim(),
    createdAt: new Date().toISOString(),
  };
  reviews.push(newReview);
  saveReviews(reviews);
  return true;
}

function getGeneralReviews(login) {
  const reviews = getReviews();
  return reviews
    .filter((r) => r.userLogin === login && r.applicationId === null)
    .sort((a, b) => b.id - a.id);
}

// Для совместимости со старым кодом, если где-то используется addReview / getUserReviews
function addReview(userLogin, text) {
  return addGeneralReview(userLogin, text);
}
function getUserReviews(login) {
  return getGeneralReviews(login);
}

// Проверка авторизации и редиректы на страницах
function requireAuth(redirectToLogin = true) {
  const current = getCurrentUser();
  if (!current) {
    if (redirectToLogin) window.location.href = "login.html";
    return null;
  }
  return current;
}

function requireUserRole() {
  const user = requireAuth();
  if (user && user.role === "admin") {
    window.location.href = "admin.html";
    return null;
  }
  return user;
}

function requireAdminRole() {
  const user = requireAuth();
  if (!user) return null;
  if (user.role !== "admin") {
    window.location.href = "index.html";
    return null;
  }
  return user;
}

function logout() {
  clearCurrentUser();
  window.location.href = "login.html";
}

initStorage();
