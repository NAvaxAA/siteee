const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bodyParser = require("body-parser");
const crypto = require("crypto");

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public")); // папка с HTML, CSS, JS

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "P@ssw0rd",
  database: "korochki_db",
});

db.connect((err) => {
  if (err) throw err;
  console.log("✅ Подключено к MySQL");
});

function hashPassword(pwd) {
  return crypto.createHash("md5").update(pwd).digest("hex");
}

// ---------- API ----------
app.post("/api/register", (req, res) => {
  const { login, password, fullname, phone, email } = req.body;
  const hashed = hashPassword(password);
  const sql =
    "INSERT INTO users (login, password, fullname, phone, email) VALUES (?, ?, ?, ?, ?)";
  db.query(sql, [login, hashed, fullname, phone, email], (err, result) => {
    if (err)
      return res
        .status(400)
        .json({ success: false, error: "Логин занят или ошибка данных" });
    res.json({ success: true });
  });
});

app.post("/api/login", (req, res) => {
  const { login, password } = req.body;
  const hashed = hashPassword(password);
  const sql =
    "SELECT id, login, fullname, role FROM users WHERE login = ? AND password = ?";
  db.query(sql, [login, hashed], (err, results) => {
    if (err || results.length === 0)
      return res
        .status(401)
        .json({ success: false, error: "Неверный логин/пароль" });
    const user = results[0];
    res.json({
      success: true,
      user: {
        id: user.id,
        login: user.login,
        fullname: user.fullname,
        role: user.role,
      },
    });
  });
});

app.get("/api/applications/:userId", (req, res) => {
  const userId = req.params.userId;
  const sql = "SELECT * FROM applications WHERE user_id = ? ORDER BY id DESC";
  db.query(sql, [userId], (err, results) => {
    if (err) return res.status(500).json([]);
    res.json(results);
  });
});

app.post("/api/applications", (req, res) => {
  const { userId, courseName, startDate, paymentMethod } = req.body;
  const sql =
    'INSERT INTO applications (user_id, course_name, start_date, payment_method, status) VALUES (?, ?, ?, ?, "Новая")';
  db.query(
    sql,
    [userId, courseName, startDate, paymentMethod],
    (err, result) => {
      if (err) return res.status(500).json({ success: false });
      res.json({ success: true, id: result.insertId });
    },
  );
});

app.put("/api/applications/:id", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const sql = "UPDATE applications SET status = ? WHERE id = ?";
  db.query(sql, [status, id], (err) => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true });
  });
});

app.get("/api/all-applications", (req, res) => {
  const sql =
    "SELECT a.*, u.login as userLogin FROM applications a JOIN users u ON a.user_id = u.id ORDER BY a.id DESC";
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json([]);
    res.json(results);
  });
});

app.get("/api/reviews/application/:appId", (req, res) => {
  const { appId } = req.params;
  const sql =
    "SELECT * FROM reviews WHERE application_id = ? ORDER BY created_at DESC";
  db.query(sql, [appId], (err, results) => {
    res.json(results);
  });
});

app.post("/api/reviews/application", (req, res) => {
  const { userId, applicationId, text } = req.body;
  const sql =
    "INSERT INTO reviews (user_id, application_id, text) VALUES (?, ?, ?)";
  db.query(sql, [userId, applicationId, text], (err) => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true });
  });
});

app.get("/api/reviews/general/:userId", (req, res) => {
  const { userId } = req.params;
  const sql =
    "SELECT * FROM reviews WHERE user_id = ? AND application_id IS NULL ORDER BY created_at DESC";
  db.query(sql, [userId], (err, results) => {
    res.json(results);
  });
});

app.post("/api/reviews/general", (req, res) => {
  const { userId, text } = req.body;
  const sql =
    "INSERT INTO reviews (user_id, application_id, text) VALUES (?, NULL, ?)";
  db.query(sql, [userId, text], (err) => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true });
  });
});

app.listen(port, () => {
  console.log(`🚀 Сервер запущен на http://localhost:${port}`);
});
